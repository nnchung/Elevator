#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Simulate the elevator environment.

"""

# core modules
import random
import math
import copy

# 3rd party modules
import gym
import numpy as np
from gym import spaces


def generate_commuter(lmax):
    return np.random.choice(lmax, 2, replace=False) + 1


class LiftEnv(gym.Env):

    """
    Define a simple Lift environment.
     The environment defines which actions can be taken at which point and
    when the agent receives which reward.
    """

    def __init__(self):
        self.__version__ = "0.1.0"
        print("LiftEnv - Version {}".format(self.__version__))

        ################################### General variables defining the environment #################################
        self.NUM_LEVEL = 4                               # total number of floor
        self.LIFT_CAPACITY = 15                          # capacity of elevator car
        self.MAX_NUM_STATE = 20
        self.LIMIT = 100                                 # maximum number of commuters in the environment
        self.LOADING_TIME = 0.2                          # time taken to load a commuter
        self.TRAVEL_TIME = 2.0                           # time taken to traverse a level
        self.OPEN_TIME = 0.5                             # time taken to open lift door
        self.CLOSE_TIME = 0.5                            # time taken to close lift door
        self.SIGNALING = 0.2                             # the time passed when the elevator stay at the same floor
        self.AVERAGE_NUM_COM = 3.0                       # average number of commuter generated at one time (lambda)
        self.TOTAL_STEP = 10000                          # total time for an episode
        self.ACTIONSET = range(1,2*self.NUM_LEVEL+1)     # action set [1up, 2up, ..., (L-1)up, 2down, 3down, ..., Ldown]
        self.ACTIONSET.remove(self.NUM_LEVEL+1)
        self.ACTIONSET.remove(self.NUM_LEVEL)

        self.action_space = spaces.Discrete(2*self.NUM_LEVEL-2)

        ######################### Observation ##############################
        low = np.zeros((3,self.NUM_LEVEL), dtype=int)
        high = self.MAX_NUM_STATE * np.ones((3,self.NUM_LEVEL), dtype=int)
        self.observation_space = spaces.Box(low, high, dtype=int)

        ################## Store what the agent tried ######################
        self.curr_episode = -1
        self.action_episode_memory = []
        self.waiting_time = []
        self.distance_travel = []
        self.travel_time = []
        self.action_memory = []
        self.time = []
        self.FutureR = 0.0
        self.nowork = 0.0
        self.Np = 0.0
        self.curr_step = -1                              # current time step
        self.is_game_over = False
        self.level_commuters = []
        self.lift_commuters = []

    def step(self, action):
        """
        The agent takes a step in the environment.
         Parameters
        ----------
        action : int
         Returns
        -------
        ob, reward, episode_over, info : tuple
            ob (object) :
                an environment-specific object representing your observation of
                the environment.
            reward (float) :
                amount of reward achieved by the previous action. The scale
                varies between environments, but the goal is always to increase
                your total reward.
            episode_over (bool) :
                whether it's time to reset the environment again. Most (but not
                all) tasks are divided up into well-defined episodes, and done
                being True indicates the episode has terminated. (For example,
                perhaps the pole tipped too far, or you lost your last life.)
            info (dict) :
                 diagnostic information useful for debugging. It can sometimes
                 be useful for learning (for example, it might contain the raw
                 probabilities behind the environment's last state change).
                 However, official evaluations of your agent are not allowed to
                 use this for learning.
        """
        if self.is_game_over:
            raise RuntimeError("Episode is done")
        self.curr_step += 1

        self.take_action(action)
        if float(len(self.level_commuters)) + float(len(self.lift_commuters)) > 0:
            self.FutureR = 1.0
        else:
            self.FutureR = 0.0

        reward = self.get_reward()

        ####################### Generate new commuters when there are no more commuters in the system ##################
        if len(self.level_commuters) + len(self.lift_commuters) == 0:
            nn = np.random.poisson(self.AVERAGE_NUM_COM,1)
            if self.curr_time < self.TOTAL_STEP:
                for _ in range(nn):
                    self.level_commuters.append(np.append(generate_commuter(self.NUM_LEVEL),float(self.curr_time)))
                    self.distance_travel.append(abs(self.level_commuters[-1][0]-self.level_commuters[-1][1]))

        ob = self.get_state()
        self.state.append(ob)
        self.action_memory.append(action)
        self.time.append(self.curr_time)
        return ob, reward, self.is_game_over, self.FutureR

    def take_action(self, action0):
        self.action_episode_memory[self.curr_episode].append(action0)
        self.deliver = 0.0
        self.take_in = 0.0
        self.time_lapsed = 0.2
        self.nowork = 0.0
        self.Np = float(len(self.level_commuters)) + float(len(self.lift_commuters))
        self.savemode = 0.0


        if self.ACTIONSET[action0] > self.NUM_LEVEL:
            action = self.ACTIONSET[action0] - self.NUM_LEVEL          # convert action to level to go
            dir = -1                                                   # travelling direction of passenger to pick
        else:
            action = copy.copy(self.ACTIONSET[action0])
            dir = 1

        if self.Np == 0 and action == self.lift_level:                 # save energy by not moving if there is no demand
            self.savemode = 0.2

        if action == self.lift_level:
            self.curr_time += self.SIGNALING
        else:
            self.curr_time += self.CLOSE_TIME + self.TRAVEL_TIME * abs(action - self.lift_level) + self.OPEN_TIME

        if action == self.lift_level:
            self.time_lapsed = 0.2*self.SIGNALING
        else:
            self.time_lapsed = 0.2*(self.CLOSE_TIME + self.OPEN_TIME + self.TRAVEL_TIME * abs(action - self.lift_level))

        self.lift_level = copy.copy(action)

        ###################################################### Deliver #################################################
        index = []
        for c in range(len(self.lift_commuters)):                       # commuter in lift
            commuter = self.lift_commuters[c]
            if commuter[1] == self.lift_level:                          # commuter's destination is lift level
                index.append(c)

        indexes = sorted(index, reverse=True)
        self.deliver = 1.0*float(len(indexes))
        for i in indexes:
            self.travel_time.append(self.curr_time - self.lift_commuters[i][2])
            del self.lift_commuters[i]

            self.curr_time += self.LOADING_TIME

        ###################################################### Pick up #################################################
        space = self.LIFT_CAPACITY - len(self.lift_commuters)           # space available in elevator car
        indexL = []

        for cc in range(len(self.level_commuters)):
            commuter = self.level_commuters[cc]

            if commuter[0] == self.lift_level:                          # commuter at lift level
                com_dir = commuter[1]-commuter[0]
                if dir > 0 and com_dir > 0:
                    indexL.append(cc)
                elif dir < 0 and com_dir < 0:
                    indexL.append(cc)

        if len(indexL) > space:                                         # if commuter exceed space, choose randomly
            indexL = np.random.choice(indexL, space, replace=False)
        indexesL = sorted(indexL, reverse=True)
        self.take_in = 1.0*float(len(indexesL))

        for i in indexesL:
            self.waiting_time.append(self.curr_time - self.level_commuters[i][2])
            self.level_commuters[i][2] = self.curr_time
            self.lift_commuters.append(self.level_commuters[i])
            if len(self.level_commuters) == 1:
                self.level_commuters = []
            else:
                del self.level_commuters[i]
            self.curr_time += self.LOADING_TIME                          # update time considering pick up

        if self.Np > 0.0 and self.deliver + self.take_in == 0.0:
            self.nowork = -10.0                                          # punishment for not clearing demand

        if len(self.level_commuters) >= self.LIMIT:                      # terminate the episode if number of commuter over limit
            self.is_game_over = True


    def get_reward(self):
        ob2 = self.get_state()
        return 0.0 - self.time_lapsed * (self.deliver+np.sum(ob2[:self.NUM_LEVEL+1,:])) + self.nowork + self.savemode


    def reset(self):
        """
        Reset the state of the environment and returns an initial observation.
         Returns
        -------
        observation (object): the initial observation of the space.
        """
        self.curr_episode += 1
        self.curr_time = 0.0
        self.action_episode_memory.append([])
        self.is_game_over = False
        self.lift_level = 1
        self.level_commuters = []
        self.lift_commuters = []
        self.waiting_time = []
        self.travel_time = []
        self.state = []
        self.time = []
        self.action_memory = []
        self.FutureR = 0.0
        self.savemode = 0.0

        self.state.append(self.get_state())
        self.time.append(self.curr_time)
        return self.get_state()

    def render(self, mode='hu2Nn', close=False):
        return


    def get_state(self):
        """Get the observation."""
        ob = np.zeros((self.NUM_LEVEL+2,self.NUM_LEVEL), dtype=float)
        if len(self.level_commuters) > 0:
            commuters_waiting = np.zeros((self.NUM_LEVEL,self.NUM_LEVEL), dtype=float)
            for com in self.level_commuters:
                commuters_waiting[int(com[0]-1), int(com[1]-1)] += 1.0
            ob[:self.NUM_LEVEL, :] = commuters_waiting
        if len(self.lift_commuters) > 0:
            commuters_in_lift = [com[1] for com in self.lift_commuters]
            UL, countsL = np.unique(commuters_in_lift, return_counts=True)
            UL = UL.astype(int)
            ob[self.NUM_LEVEL, UL-1] = [y for y in countsL]
        ob[self.NUM_LEVEL+1, self.lift_level-1] = 1.0
        return ob

    def get_lift_level(self):
        return self.lift_level

    def get_time(self):
        return self.curr_time

    def get_commuter(self):
        return self.lift_commuters

    def get_waiting_time(self):
        return self.waiting_time

    def get_travel_time(self):
        return self.travel_time

    def get_distance_travel(self):
        return self.distance_travel

    def get_state_dynamics(self):
        return self.state

    def get_time_dynamics(self):
        return self.time

    def get_action_dynamics(self):
        return self.action_memory


